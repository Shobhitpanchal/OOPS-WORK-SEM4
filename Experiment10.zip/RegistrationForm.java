import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RegistrationForm {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Registration Form");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 400);

        JLabel nameLabel = new JLabel("Name:");
        JTextField nameField = new JTextField();

        JLabel emailLabel = new JLabel("Email:");
        JTextField emailField = new JTextField();

        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField passwordField = new JPasswordField();

        JLabel confirmPasswordLabel = new JLabel("Confirm Password:");
        JPasswordField confirmPasswordField = new JPasswordField();

        JButton registerButton = new JButton("Register");
        JLabel messageLabel = new JLabel("");

        JPanel panel = new JPanel(new GridLayout(6, 2, 10, 10));
        panel.add(nameLabel); panel.add(nameField);
        panel.add(emailLabel); panel.add(emailField);
        panel.add(passwordLabel); panel.add(passwordField);
        panel.add(confirmPasswordLabel); panel.add(confirmPasswordField);
        panel.add(new JLabel()); panel.add(registerButton);
        panel.add(new JLabel()); panel.add(messageLabel);

        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText();
                String email = emailField.getText();
                String password = new String(passwordField.getPassword());
                String confirmPassword = new String(confirmPasswordField.getPassword());

                if (name.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                    messageLabel.setText("Error: All fields are required!");
                } else if (!email.contains("@")) {
                    messageLabel.setText("Error: Invalid email!");
                } else if (!password.equals(confirmPassword)) {
                    messageLabel.setText("Error: Passwords do not match!");
                } else {
                    messageLabel.setText("Registration Successful!");
                }
            }
        });

        frame.add(panel);
        frame.setVisible(true);
    }
}