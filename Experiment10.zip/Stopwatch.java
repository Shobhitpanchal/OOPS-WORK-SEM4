import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Stopwatch {
    private static boolean running = false;
    private static int elapsedTime = 0;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Stopwatch");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);

        JLabel timerLabel = new JLabel("0", SwingConstants.CENTER);
        timerLabel.setFont(new Font("Arial", Font.BOLD, 30));

        JButton startButton = new JButton("Start");
        JButton stopButton = new JButton("Stop");
        JButton resetButton = new JButton("Reset");

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(startButton);
        buttonPanel.add(stopButton);
        buttonPanel.add(resetButton);

        Timer timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (running) {
                    elapsedTime++;
                    timerLabel.setText(String.valueOf(elapsedTime));
                }
            }
        });
        timer.start();

        startButton.addActionListener(e -> running = true);
        stopButton.addActionListener(e -> running = false);
        resetButton.addActionListener(e -> {
            running = false;
            elapsedTime = 0;
            timerLabel.setText("0");
        });

        frame.setLayout(new BorderLayout());
        frame.add(timerLabel, BorderLayout.CENTER);
        frame.add(buttonPanel, BorderLayout.SOUTH);
        frame.setVisible(true);
    }
}