package Experiment2 ;

public class Ques3_ass1  {

    // method area rectangle
    public double calculatearea(double length, double width)
    {
        return length * width;
    }

    // method area square
    public double calculatearea(double side)
    {
        return side * side;
    }

    // method area circle
    public double calculatearea(double radius, boolean iscircle)
    {
       
        return Math.PI * radius * radius;
    }

    // Method area triangle
    public double calculatearea (double base, double height, boolean istriangle)
    {

        return 0.5 * base * height;
    }

    public static void main(String[] args)
    {
        Ques3_ass1 areaCalculator = new Ques3_ass1();
        System.out.println("Area Calculator");

        System.out.println("Area of Rectangle (length=5, width=4): " + areaCalculator.calculatearea(5, 4));
        System.out.println("Area of Square (side=6): " + areaCalculator.calculatearea(6));
        System.out.println("Area of Circle (radius=3): " + areaCalculator.calculatearea(3, true));
        System.out.println("Area of Triangle (base=4, height=5): " + areaCalculator.calculatearea(4, 5, true));
    }
}