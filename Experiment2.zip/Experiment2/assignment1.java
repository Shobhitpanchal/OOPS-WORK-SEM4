package Experiment2;

public class assignment1 {
	public static void main(String[] args) {
		System.out.println("Hardik lal") ;
	}

} 