package Experiment3 ;
public class Ques2_ass3 {
    public static void main(String[] args) {
        int[] arr = {1, 5, 6, 2, 4, 10, 8, 9, 3}; // Given array
        int n = arr.length + 1; // The array should contain numbers from 1 to N

        // Calculate the expected sum of numbers from 1 to N
        int expectedSum = n * (n + 1) / 2;

        // Calculate the actual sum of array elements
        int actualSum = 0;
        for (int num : arr) {
            actualSum += num;
        }

        // The missing number is the difference
        int missingNumber = expectedSum - actualSum;
        System.out.println("The missing number is: " + missingNumber);
    }
}