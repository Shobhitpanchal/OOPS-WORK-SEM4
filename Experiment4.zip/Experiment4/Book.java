//Constructor overloading
package Experiment4 ;
class Book {
    private String title;
    private String author;
    private int publicationYear;

    // Default constructor book define
    public Book() {
        this.title = "Untitled";
        this.author = "Unknown Author";
        this.publicationYear = 0;
    }

    // Constructor with title and author
    public Book(String title, String author) {
        this.title = title;
        this.author = author;
        this.publicationYear = 0;
    }

    // Constructor with title, author, and publication year
    public Book(String title, String author, int publicationYear) {
        this.title = title;
        this.author = author;
        this.publicationYear = publicationYear;
    }

    public void displayDetails() {
        System.out.println("Title: " + title + ", Author: " + author + ", Year: " + publicationYear);
    }

    public static void main(String[] args) {
        Book book1 = new Book();                                            //call construct 1 para
        Book book2 = new Book("Java Programming", "John Doe");              // 2 parameter
        Book book3 = new Book("Data Structures", "Alice Smith", 2020);      // 3 parameter

        book1.displayDetails();
        book2.displayDetails();
        book3.displayDetails();
    }
}
