package Experiment4;
class Product {
    private static int totalProducts = 0;  
    private int productId;
    private String productName;
    private String category;
    private double price;

    // Default constructor
    public Product() {
        this.productId = 0;
        this.productName = "Unknown";
        this.category = "General";
        this.price = 0.0;
        totalProducts++;
    }

    // Parameterized constructor
    public Product(int productId, String productName, String category, double price) {
        this.productId = productId;
        this.productName = productName;
        this.category = category;
        this.price = price;
        totalProducts++;
    }

    public double getPrice() {
        return price;
    }

    public void displayProductInfo() {
        System.out.println("ID: " + productId + ", Name: " + productName + ", Category: " + category + ", Price: $" + price);
    }

    public static void displayTotalProducts() {
        System.out.println("Total Products Created: " + totalProducts);
    }

    // Method Overloading: Calculate stock value with optional discount
    public double calculateStockValue(int quantity) {
        return price * quantity;
    }

    public double calculateStockValue(int quantity, double discountRate) {
        return (price * quantity) * (1 - discountRate / 100);
    }

    public static void main(String[] args) {
        Product p1 = new Product(101, "Laptop", "Electronics", 750.0);
        Product p2 = new Product(102, "Phone", "Electronics", 500.0);

        p1.displayProductInfo();
        p2.displayProductInfo();
        
        System.out.println("Stock Value (5 units): $" + p1.calculateStockValue(5));
        System.out.println("Stock Value (5 units, 10% discount): $" + p1.calculateStockValue(5, 10));

        Product.displayTotalProducts();
    }
}
