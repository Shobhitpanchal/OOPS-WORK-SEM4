package Experiment5_q1;
class SuperClass {
    private int privateData = 100; // Private member

    public int getPrivateData() {
        return privateData; // Accessing private member through a public method
    }
}