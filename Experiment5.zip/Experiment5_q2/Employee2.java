package Experiment5_q2;
public class Employee2
{
    private String name;
    private int empid;
    private double salary;

    // default constructor
    public Employee2()
    {
        this.name = "Unknown";
        this.empid = 0;
        this.salary = 0.0;
    }

    // parameterized constructor
    public Employee2(String name, int empid, double salary)
    {
        this.name = name;
        this.empid = empid;
        this.salary = salary;
    }

    // method to return the employee's name
    public String getName()
    {
        return name;
    }

    // method to return the employee's salary
    public double getSalary()
    {
        return salary;
    }

    // method to increase the salary by a specified percentage
    public void increaseSalary(double percentage)
    {
        if (percentage > 0)
        {
            this.salary += this.salary * percentage / 100;
        }
    }

    // method to display employee information
    public void displayEmployeeInfo()
    {
        System.out.println("Employee ID: " + empid);
        System.out.println("Name: " + name);
        System.out.println("Salary: $" + salary);
    }
}
