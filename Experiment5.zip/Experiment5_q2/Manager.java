package Experiment5_q2;

public class Manager extends Employee2
{
    private String department;

    // default constructor
    public Manager()
    {
        super();
        this.department = "Unknown";
    }

    // parameterized constructor
    public Manager(String name, int empid, double salary, String department)
    {
        super(name, empid, salary);
        this.department = department;
    }

    // method to display manager information
    @Override
    public void displayEmployeeInfo()
    {
        super.displayEmployeeInfo();
        System.out.println("Department: " + department);
    }
}
