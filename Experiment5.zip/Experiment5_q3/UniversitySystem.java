package Experiment5_q3;

//Main class to demonstrate polymorphism
public class UniversitySystem {
 public static void main(String[] args) {
     // Creating instances of Professor and GraduateStudent
     Professor prof = new Professor("Dr. Smith", 50, "123 University St", "P101", "Computer Science", "AI & ML");
     GraduateStudent gradStudent = new GraduateStudent("Alice Johnson", 24, "456 College Ave", "S201", "M.Sc. Physics", "Quantum Computing");

     // Array of Person references holding different subclass objects
     Person[] people = {prof, gradStudent};

     // Demonstrating polymorphism
     for (Person p : people) {
         p.displayInfo(); // Calls overridden methods
         System.out.println(); 

         // Type casting to access specific methods
         if (p instanceof Professor) {
             ((Professor) p).conductLecture();
         } else if (p instanceof GraduateStudent) {
             ((GraduateStudent) p).submitThesis();
         }
         System.out.println("----------------------------");
     }
 }
}