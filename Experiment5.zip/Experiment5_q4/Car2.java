package Experiment5_q4;

public class Car2 extends Vehicle
{

    // constructor to initialize make and model
    public Car2(String make, String model)
    {
        super(make, model);
    }

    // implementation of startEngine method
    @Override
    public void startEngine()
    {
        System.out.println("Starting the engine of the " + make + " " + model + ".");
    }

    // implementation of stopEngine method
    @Override
    public void stopEngine()
    {
        System.out.println("Stopping the engine of the " + make + " " + model + ".");
    }
}
