package Experiment5_q4;

import java.util.Scanner;

public class TestProgramVehicle
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("CAR MANAGEMENT SYSTEM");
        System.out.print("Enter the make of the car: ");
        String make = scanner.nextLine();

        System.out.print("Enter the model of the car: ");
        String model = scanner.nextLine();

        // instantiate a Car object
        Car2 myCar = new Car2(make, model);

        // call all available methods
        myCar.startEngine();
        myCar.stopEngine();
        myCar.serviceInfo();

        scanner.close();
    }
}