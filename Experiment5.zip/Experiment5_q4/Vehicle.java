package Experiment5_q4;
public abstract class Vehicle
{
    protected String make;
    protected String model;

    // constructor to initialize make and model
    public Vehicle(String make, String model)
    {
        this.make = make;
        this.model = model;
    }

    // abstract methods
    public abstract void startEngine();
    public abstract void stopEngine();

    // non-abstract method
    public void serviceInfo()
    {
        System.out.println("Basic servicing instructions for " + make + " " + model + ":");
        System.out.println("1. Check engine oil.");
        System.out.println("2. Check tire pressure.");
        System.out.println("3. Check brake fluid.");
        System.out.println("4. Check coolant level.");
    }
}
