package Experiment5_q5;
public class Chef  //base class
{
    public void makeSpecialDish()
    {
        System.out.println("The chef is making a special dish.");
    }
}
