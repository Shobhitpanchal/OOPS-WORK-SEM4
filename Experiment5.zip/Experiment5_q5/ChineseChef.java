package Experiment5_q5;

public class ChineseChef extends Chef
{
    @Override
    public void makeSpecialDish()
    {
        System.out.println("Making dumplings.");
    }
}
