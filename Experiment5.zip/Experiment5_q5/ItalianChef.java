package Experiment5_q5;

public class ItalianChef extends Chef
{
    @Override
    public void makeSpecialDish()
    {
        System.out.println("Making pasta.");
    }
}