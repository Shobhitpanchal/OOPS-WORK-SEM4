package Experiment5_q5;

public class MexicanChef extends Chef
{
    @Override
    public void makeSpecialDish()
    {
        System.out.println("Making tacos.");
    }
}

