// used polymorphism & Method Overriding
package Experiment5_q5;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TestProgramChef
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        List<Chef> chefs = new ArrayList<>();
System.out.println("Chef Management System");
        System.out.println("Enter the number of chefs: ");
        int numChefs = scanner.nextInt();
        scanner.nextLine(); // consume nl

        for (int i = 0; i < numChefs; i++)
        {
            System.out.println("Enter the type of chef (Italian, Chinese, Mexican): ");
            String chefType = scanner.nextLine();

            switch (chefType.toLowerCase())
            {
                case "italian":
                    chefs.add(new ItalianChef());
                    break;
                case "chinese":
                    chefs.add(new ChineseChef());
                    break;
                case "mexican":
                    chefs.add(new MexicanChef());
                    break;
                default:
                    System.out.println("Unknown chef type. Adding a generic chef.");
                    chefs.add(new Chef());
                    break;
            }
        }

        System.out.println("\nSpecial Dishes:");
        for (Chef chef : chefs) {
            chef.makeSpecialDish();
        }

        scanner.close();
    }
}