// package Own;

// import Experiment6.Ques3_ass6;

// public class Main_Ques3_ass6 {
//     public static void main(String[] args) {
//         Ques3_ass6 s1 = new Ques3_ass6(101, "Alice", 'A');
//         s1.displayStudentInfo();
//     }
// }
