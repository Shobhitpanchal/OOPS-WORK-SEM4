package Experiment6;

public final class SecuritySystem {
    public void authenticateUser(String username, String password) {
        if (username.equals("admin") && password.equals("1234")) {
            System.out.println("Login successful!");
        } else {
            System.out.println("Invalid credentials.");
        }
    }
}
