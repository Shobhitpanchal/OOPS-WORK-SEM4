// package Own ;
// import Experiment6.BankAccount;

// public class UserAccount {
//     public static void main(String[] args) {
//         BankAccount account = new BankAccount();
//         account.deposit(1000); // ✅ Accessible (public)
        
//         // account.withdraw(500); // ❌ Not accessible (protected, different package)
//         // account.checkBalance(); // ❌ Not accessible (default, different package)
//         // account.calculateInterest(); // ❌ Not accessible (private)
//     }
// }
