package Experiment7_q1;

abstract class Solid {
    abstract double calculateVolume();
}