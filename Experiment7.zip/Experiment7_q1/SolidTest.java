package Experiment7_q1;
public class SolidTest {
    public static void main(String[] args) {
        Cuboid cuboid = new Cuboid(4, 5, 6);
        Sphere sphere = new Sphere(3);

        System.out.println("Cuboid Volume: " + cuboid.calculateVolume());
        System.out.println("Sphere Volume: " + sphere.calculateVolume());
    }
}