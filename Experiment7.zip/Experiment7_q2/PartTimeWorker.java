package Experiment7_q2;
class PartTimeWorker extends Worker {
    private String name;
    private double hourlyRate;
    private int hoursWorked;

    PartTimeWorker(String name, double rate, int hours) {
        this.name = name;
        this.hourlyRate = rate;
        this.hoursWorked = hours;
    }

    @Override
    void computePay() {
        System.out.println(name + "'s Weekly Pay: " + (hourlyRate * hoursWorked));
    }

    @Override
    void displayInfo() {
        System.out.println("Part-Time Worker: " + name);
    }
}
