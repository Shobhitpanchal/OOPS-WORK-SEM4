package Experiment7_q2;
abstract class Worker {
    abstract void computePay();
    abstract void displayInfo();
}
