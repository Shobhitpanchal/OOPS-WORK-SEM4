package Experiment7_q2;
public class WorkerTest {
    public static void main(String[] args) {
        FullTimeWorker ftw = new FullTimeWorker("Alice", 5000);
        PartTimeWorker ptw = new PartTimeWorker("Bob", 20, 25);

        ftw.displayInfo();
        ftw.computePay();

        ptw.displayInfo();
        ptw.computePay();
    }
}