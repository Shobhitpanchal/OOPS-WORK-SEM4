package Experiment7_q4;

public interface Remote {
	    void powerOn();
	    void powerOff();
	    void changeChannel(int channel);
	}