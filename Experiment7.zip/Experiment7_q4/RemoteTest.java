package Experiment7_q4;
public class RemoteTest {
    public static void main(String[] args) {
        Remote myTV = new Television();
        myTV.powerOn();
        myTV.changeChannel(5);
        myTV.powerOff();
    }
}