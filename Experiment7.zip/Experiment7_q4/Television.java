package Experiment7_q4;
class Television implements Remote {
    @Override
    public void powerOn() {
        System.out.println("TV is now ON.");
    }

    @Override
    public void powerOff() {
        System.out.println("TV is now OFF.");
    }

    @Override
    public void changeChannel(int channel) {
        System.out.println("Channel changed to: " + channel);
    }
}
