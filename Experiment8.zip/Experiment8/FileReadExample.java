import java.io.*;
import java.util.Scanner;

public class FileReadExample {

    // Method that reads a file and throws FileNotFoundException
    public static void readFile(String fileName) throws FileNotFoundException {
        File file = new File(fileName);
        Scanner sc = new Scanner(file); // This can throw FileNotFoundException

        // Read and print each line
        while (sc.hasNextLine()) {
            System.out.println(sc.nextLine());
        }

        sc.close();
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the filename: ");
        String fileName = input.nextLine();

        try {
            readFile(fileName); // May throw FileNotFoundException
        } catch (FileNotFoundException e) {
            System.out.println("Error: File not found.");
        } finally {
            System.out.println("File operation attempted.");
        }

        input.close();
    }
}
