import java.io.*;
public class PersonSerialization {
    public static void main(String[] args) {
        // Serialize
        try {
            Person p1 = new Person("John", 30);
            FileOutputStream fos = new FileOutputStream("person.txt");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(p1);
            oos.close();
            fos.close();
            System.out.println("Person object serialized.");
        } catch (IOException e) {
            System.out.println("Error during serialization.");
        }

        // Deserialize
        try {
            FileInputStream fis = new FileInputStream("person.txt");
            ObjectInputStream ois = new ObjectInputStream(fis);
            Person p2 = (Person) ois.readObject();
            ois.close();
            fis.close();

            System.out.println("Deserialized Person:");
            System.out.println("Name: " + p2.name);
            System.out.println("Age: " + p2.age);
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error during deserialization.");
        }
    }
}