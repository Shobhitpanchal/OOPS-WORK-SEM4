import java.io.*;

public class StudentReader {
    public static void main(String[] args) {
        try {
            FileReader fr = new FileReader("student.txt");
            BufferedReader br = new BufferedReader(fr);
            String line;

            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }

            br.close();
        } catch (FileNotFoundException e) {
            System.out.println("The file student.txt does not exist.");
        } catch (IOException e) {
            System.out.println("Error reading the file.");
        }
    }
}
