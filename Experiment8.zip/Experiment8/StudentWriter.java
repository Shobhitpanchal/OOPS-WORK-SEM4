import java.io.*;
import java.util.Scanner;

public class StudentWriter {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter name: ");
        String name = sc.nextLine();
        System.out.print("Enter roll number: ");
        String roll = sc.nextLine();
        System.out.print("Enter grade: ");
        String grade = sc.nextLine();

        try {
            FileWriter writer = new FileWriter("student.txt", true); // append mode
            writer.write("Name: " + name + ", Roll Number: " + roll + ", Grade: " + grade + "\n");
            writer.close();
            System.out.println("Student record written successfully.");
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file.");
        }

        sc.close();
    }
}
