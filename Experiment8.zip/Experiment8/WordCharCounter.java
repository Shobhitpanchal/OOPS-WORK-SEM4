import java.io.*;
import java.util.Scanner;

public class WordCharCounter {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter file name: ");
        String fileName = sc.nextLine();

        try {
            FileReader fr = new FileReader(fileName);
            BufferedReader br = new BufferedReader(fr);
            int charCount = 0;
            int wordCount = 0;
            String line;

            while ((line = br.readLine()) != null) {
                charCount += line.replaceAll("\\s+", "").length(); // remove all whitespaces
                String[] words = line.trim().split("\\s+");
                if (!line.trim().isEmpty()) {
                    wordCount += words.length;
                }
            }

            System.out.println("Characters (excluding whitespace): " + charCount);
            System.out.println("Words: " + wordCount);

            br.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file.");
        }

        sc.close();
    }
}
