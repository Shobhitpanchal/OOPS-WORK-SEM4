package Experiment9 ;
import java.util.ArrayList;
import java.util.Scanner;

class Employee {
    String name;
    int id;
    double salary;

    public Employee(String name, int id, double salary) {
        this.name = name;
        this.id = id;
        this.salary = salary;
    }

    @Override
    public String toString() {
        return String.format("Employee{name='%s', id=%d, salary=%.2f}", name, id, salary);
    }
}