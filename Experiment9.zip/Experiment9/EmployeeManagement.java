package Experiment9 ;

import java.util.ArrayList;
import java.util.Scanner;
public class EmployeeManagement {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Employee> employees = new ArrayList<>();

        System.out.println("Enter employee details (name id salary), type 'done' when finished:");
        while (true) {
            System.out.print("> ");
            String input = scanner.nextLine();
            if (input.equalsIgnoreCase("done")) break;

            String[] parts = input.split(" ");
            employees.add(new Employee(parts[0], Integer.parseInt(parts[1]), Double.parseDouble(parts[2])));
        }

        System.out.print("\nEnter ID of employee to update salary: ");
        int updateId = scanner.nextInt();
        System.out.print("Enter new salary: ");
        double newSalary = scanner.nextDouble();
        scanner.nextLine(); // Consume newline

        for (Employee emp : employees) {
            if (emp.id == updateId) {
                emp.salary = newSalary;
                break;
            }
        }

        System.out.print("Enter ID of employee to remove: ");
        int removeId = scanner.nextInt();

        employees.removeIf(emp -> emp.id == removeId);

        System.out.println("\nRemaining Employees:");
        employees.forEach(System.out::println);
        scanner.close();
    }
}