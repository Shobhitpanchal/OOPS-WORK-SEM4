package Experiment9;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;

public class NameDeduplication {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter names separated by commas: ");
        String[] names = scanner.nextLine().split(",");
        
        HashSet<String> uniqueNames = new HashSet<>(Arrays.asList(names));
        
        System.out.print("\nEnter name to search: ");
        String searchName = scanner.nextLine().trim();
        
        System.out.println("Does '" + searchName + "' exist? " + 
                          (uniqueNames.contains(searchName) ? "Yes" : "No"));
        
        System.out.println("\nUnique Names:");
        uniqueNames.forEach(name -> System.out.println(name.trim()));
        scanner.close();
    }
}