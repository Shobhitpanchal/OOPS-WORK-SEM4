package Experiment9;
import java.util.ArrayList;
import java.util.Scanner;

public class PrimeNumberCheck {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Create ArrayList to store integers
        ArrayList<Integer> numbers = new ArrayList<>();
        
        System.out.println("Enter the number of integers you want to check:");
        int count = scanner.nextInt();
        
        System.out.println("Enter " + count + " integers:");
        for (int i = 0; i < count; i++) {
            // Using autoboxing to store primitive int as Integer object
            numbers.add(scanner.nextInt());
        }
        
        // Iterate through the list, unbox and check for primes
        System.out.println("\nPrime Number Check Results:");
        for (Integer num : numbers) {
            int n = num; // Unboxing
            boolean isPrime = isPrime(n);
            System.out.println(n + " is " + (isPrime ? "prime" : "not prime"));
        }
        
        scanner.close();
    }

    private static boolean isPrime(int num) {
        if (num <= 1) return false;
        if (num == 2) return true;
        if (num % 2 == 0) return false;
        
        for (int i = 3; i <= Math.sqrt(num); i += 2) {
            if (num % i == 0) return false;
        }
        return true;
    }
}