package Experiment9;
import java.util.HashMap;
import java.util.Scanner;

public class ProductInventory {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        HashMap<Integer, Integer> inventory = new HashMap<>();

        System.out.println("Add products (id quantity), type 'done' when finished:");
        while (true) {
            System.out.print("> ");
            String input = scanner.nextLine();
            if (input.equalsIgnoreCase("done")) break;

            String[] parts = input.split(" ");
            inventory.put(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]));
        }

        System.out.print("\nEnter product ID to update: ");
        int updateId = scanner.nextInt();
        System.out.print("Enter new quantity: ");
        int newQty = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        inventory.put(updateId, newQty);

        System.out.print("Enter product ID to remove: ");
        int removeId = scanner.nextInt();
        inventory.remove(removeId);

        System.out.println("\nFinal Inventory:");
        inventory.forEach((id, qty) -> System.out.println("Product ID: " + id + ", Quantity: " + qty));
        scanner.close();
    }
}