package Experiment9;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;

public class UniqueSum {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Integer> numbers = new ArrayList<>();

        System.out.print("Enter numbers separated by spaces: ");
        String[] inputs = scanner.nextLine().split(" ");

        for (String input : inputs) {
            numbers.add(Integer.parseInt(input));
        }

        HashSet<Integer> uniqueNumbers = new HashSet<>(numbers);
        int sum = uniqueNumbers.stream().mapToInt(Integer::intValue).sum();

        System.out.println("\nUnique values: " + uniqueNumbers);
        System.out.println("Sum: " + sum);
        scanner.close();
    }
}